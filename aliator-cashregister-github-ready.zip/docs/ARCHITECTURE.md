# Architecture / アーキテクチャ

## English — component responsibilities

The application consists of a central Spring Boot / PostgreSQL service and restaurant-side presentation/printing components.

| Area | Responsibility | Implementation notes |
| --- | --- | --- |
| Web/API backend | Tenant-scoped restaurant management, orders, QR sessions, demo checkout, reporting, printer jobs | Java 21, Spring Boot, JDBC; ensure all requests and queries validate tenant access |
| Guest ordering | Table QR entry, translated menu, order submission | Browser UI + Spring endpoints; session tokens should rotate after checkout |
| Kitchen | Show orders and preparation state | Web UI backed by restaurant-scoped data; delivery confirmation is configurable |
| Cashier | Demo cash/card recording, bill closure | This is NOT gateway integration or real payment authorization |
| Reporting | Daily/weekly/monthly/yearly operational views | Database-backed aggregates scoped to the current restaurant |
| Print outbox | Store jobs transactionally and deduplicate logical jobs | Database state distinguishes pending/claimed/acknowledged/uncertain cases |
| Print bridge | Poll authorized endpoint and spool jobs locally | Java service on Raspberry Pi; printer-only credentials must never go into Git |
| Print agent | Convert text/layout into TSPL-compatible printer data | Java / bitmap CJK rendering; USB `lp0` printer endpoint |
| Kiosk | Restaurant terminal UI | Chromium in kiosk mode under Wayland/labwc |
| Deployment | Containerized application + database; reverse proxy; device services | Docker Compose, Nginx/HTTPS, Raspberry Pi systemd |

### Repository source layout (historical reference, not committed here)

The following tree is based on development notes through V8. It is **not a claim** that the latest V17 deployment has identical paths; validate against the live source tree before committing application code.

```text
application-root/
├── Dockerfile
├── compose.yaml
├── pom.xml
├── src/main/java/com/aliator/cashregister/
│   ├── v2/       # restaurant/QR/guest ordering
│   ├── v3/       # demo checkout/reports
│   ├── v4/       # print API and job lifecycle
│   ├── v5/       # translations / multilingual menu schema
│   ├── v6/       # registration OTP
│   ├── v7/       # account recovery
│   └── v8/       # printer/workflow preferences
└── src/main/resources/static/
    ├── portal.html
    ├── guest.html
    ├── cashier.html
    ├── reports.html
    ├── print.html
    └── workflow.html
```

### Engineering choices

- **Tenant separation:** Every restaurant should receive only its own data; database access must be scoped and tested rather than relying on UI filters.
- **Transaction-aware printing:** Recording an order and its print intent together reduces missing tickets; idempotency/deduplication limits duplicate print jobs.
- **Delivery is not print confirmation:** An acknowledged job can still fail to appear on paper (USB, hardware, mechanical failures). Treat ambiguous jobs explicitly.
- **Session lifecycle:** Closing the bill invalidates the previous table guest session rather than reusing a permanent order token.
- **Offline print buffering:** Device-side spool helps when the network or printer briefly fails; recovery behavior should be tested.
- **Kiosk vs server:** Raspberry Pi handles local interaction and peripherals; the central Java server remains the source of truth.

## 日本語 — コンポーネント構成

中央サーバーで **Java 21 / Spring Boot / PostgreSQL** を動作させ、注文・店舗管理・レポート・印刷ジョブを処理します。店内の **Raspberry Pi 4** はChromiumキオスクと印刷ブリッジ／エージェントを担当し、USB接続の **Zjiang ZJ-9220** にTSPL形式で注文票を出力します。

- **ゲスト注文:** QRコードからテーブル専用セッションを発行し、商品選択と注文を受け付けます。
- **キッチン:** 注文一覧・調理状態・必要な配膳確認を表示します。
- **レジ:** 現金・カードの**模擬**会計とテーブルのクローズを扱います。
- **管理者画面:** 店舗設定、メニュー管理、注文・売上集計、印刷設定を提供します。
- **印刷ジョブ:** 注文と印刷依頼を関連付けて保存し、重複防止・キュー処理・送信結果を管理します。
- **端末側印刷:** Raspberry Pi上のJavaサービスがジョブを取得・保存・描画し、USBプリンターに送信します。
- **セキュリティ:** 店舗間のデータ分離、ゲストセッションの期限・更新、印刷端末専用認証、秘密情報の非公開が重要です。

**注意:** このドキュメントのソースディレクトリ例は過去の開発構成に基づくものです。最新の稼働版と一致するか確認してから公開してください。実決済、税法対応、物理的な印刷完了の保証を示すものではありません。
