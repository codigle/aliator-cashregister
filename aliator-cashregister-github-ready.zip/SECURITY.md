# Security and publication rules / セキュリティ・公開時の注意

## English

This is a portfolio demonstration. Do **not** commit real deployment configuration, even to a private Git repository unless there is a clear need and an appropriate secret-management process.

**Never publish:** `.env` or environment overrides, API tokens, SMTP passwords, printer bearer tokens, OAuth secrets, database connection strings with credentials, private customer information, owner/staff email lists, logs containing tokens, database dumps, backup ZIP/TAR archives, TLS private keys, real invoices, or photos of customer data.

Before pushing actual source code:

1. Work from a **sanitized copy** of the deployment, not directly from the live production folder.
2. Search tracked files and Git history for tokens, passwords, credentials, private IPs and customer records.
3. Replace credentials with empty example placeholders, rotate any secrets that were ever committed, and keep sensitive values in a proper secret store.
4. Verify third-party assets (menu photos, fonts, logos) are licensed for redistribution.
5. Run the build/tests and verify that deployment-specific paths and hosts are configurable rather than hard-coded.
6. Treat the source-code license as **not specified** unless the owner explicitly selects one.

### Git publication check

```bash
# Inspect exactly what will be committed. The following commands do not push.
git status --short
git ls-files
git diff --cached --stat

# Optional: run a dedicated secret scanner such as gitleaks before publishing.
# Do not paste scan output containing actual credentials into public issues.
```

## 日本語

公開リポジトリには、本番環境の`.env`、APIキー、SMTPパスワード、プリンター用トークン、DB接続情報、個人情報、ログ、バックアップ、TLS秘密鍵、顧客情報を**絶対に追加しないでください**。

公開前に、**本番環境から分離したコピー**を使用し、ソースコードとGit履歴を検査してください。秘密情報が一度でもコミットされた場合は、履歴から削除するだけでなく、該当する認証情報を失効・再発行する必要があります。商品画像・フォント・ロゴなどの再配布権も確認してください。

このドキュメントにはオープンソースライセンスを付与していません。ライセンスはリポジトリ所有者が決定してください。
