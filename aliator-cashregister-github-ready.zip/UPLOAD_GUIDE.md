# Publish to GitHub / GitHubへの公開

The linked GitHub connector used to prepare these files can read and modify existing repositories, but cannot create new repositories. **The repository has not been created remotely.**

## Create a new repository

1. Open https://github.com/new while signed into the intended `codigle` account.
2. Repository name: `aliator-cashregister`
3. Description (EN): `Java 21 / Spring Boot restaurant POS demo with QR ordering, kitchen dashboard, PostgreSQL, and Raspberry Pi label printing.`
4. Description (JA): `Java / Spring Bootで構築した飲食店向けPOSデモ。QR注文、キッチン管理、PostgreSQL、Raspberry Piによるラベル印刷に対応。`
5. Choose **Public** if this is intended as a public portfolio; choose **Private** otherwise.
6. Leave the automatic README initialization **unchecked** because this package already contains `README.md`.
7. Create the repository, then add the files in this package. If Git is installed, from the extracted folder:

```bash
git init
git add README.md SECURITY.md .gitignore docs/ARCHITECTURE.md
git commit -m "docs: bilingual project overview and architecture"
git branch -M main
git remote add origin https://github.com/codigle/aliator-cashregister.git
git push -u origin main
```

GitHub authentication may be required. **Do not copy any personal access token into the repository or share it in a chat.**

The package contains documentation, not the real project source. Review, build and sanitize the current source before any later code commit.

## 日本語

GitHubで新規リポジトリ`aliator-cashregister`を作成し、このパッケージ内の`README.md`、`docs/ARCHITECTURE.md`、`SECURITY.md`、`.gitignore`を追加してください。実際のソースコードは含まれていません。本番ソースの公開前には、必ず秘密情報と個人情報を除去してください。
