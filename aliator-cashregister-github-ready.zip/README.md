# Aliator CashRegister

**A Java-powered restaurant ordering, point-of-sale demo and kitchen-printing system.**  
**Javaベースの飲食店向け注文・POSデモ・キッチン印刷システム。**

[English](#english) · [日本語](#日本語) · [Architecture / アーキテクチャ](docs/ARCHITECTURE.md) · [Security / セキュリティ](SECURITY.md)

> **Portfolio / demonstration project.** Cash and card payments in this project are **simulated**; this repository should not be presented as a certified payment terminal, a legally compliant Japanese invoicing system, or a production-ready commercial POS.  
> **ポートフォリオ・デモ用プロジェクトです。** 現金・カード決済は**シミュレーション**であり、認証済み決済端末・適格請求書対応システム・商用利用可能なPOSを意味するものではありません。

---

## English

### Overview

Aliator CashRegister demonstrates an end-to-end restaurant workflow: a guest scans a QR code at a table, browses a multilingual menu, places an order, and kitchen staff see it in their dashboard. Staff can mark dishes as prepared, the cashier can complete a **demo** checkout, and managers can review sales reports. A Raspberry Pi–based printer bridge and agent connect the web application to a physical USB label printer for kitchen tickets.

The system is designed around restaurant-specific data separation, session lifecycle management, and a durable print-job workflow rather than a collection of disconnected screens.

### Main features

- **QR table ordering:** Table-scoped guest sessions, menu browsing, ordering, and session/QR rotation when the bill is closed.
- **Restaurant management:** Restaurant/tenant administration, menu items, table management, and printer/workflow preferences.
- **Kitchen operations:** Incoming order display, preparation status, and optional delivery-confirmation flow.
- **Demo POS:** Cash/card payment simulation, itemized bill/receipt views, and table checkout (no real payment gateway).
- **Owner reports:** Sales and order analytics with day/week/month/year views.
- **Physical ticket printing:** Printer-specific jobs, retry/acknowledgement states, and USB label output through a Raspberry Pi.
- **Localization:** Japanese-first interface with English, Chinese, Korean and Turkish localization work; Japanese/Korean/Chinese font support matters for receipts and labels.
- **Touchscreen usage:** Browser-based tablet interface and Raspberry Pi Chromium kiosk.

### Technology — what is used where?

| Technology | Used in | Purpose |
| --- | --- | --- |
| **Java 21** | Web server and Raspberry Pi print components | Main backend logic and the printer-side services |
| **Spring Boot 3.x** | Application server | HTTP APIs, tenant administration, order/session/payment-demo workflows, reports and print-job endpoints |
| **Spring JDBC / JdbcTemplate** | Backend data access | Explicit SQL operations scoped to each restaurant |
| **PostgreSQL** | Database container | Restaurant data, menus, tables, guest sessions, orders, reporting data and print jobs |
| **HTML / CSS / JavaScript** | Web UI bundled with the application | Guest menu, kitchen, cashier, manager, reports and printer settings |
| **Docker / Docker Compose** | Linux application host | Packages and runs the Java application and PostgreSQL together |
| **Nginx + HTTPS** | Public application entry point | TLS termination and reverse proxy to the Java web application |
| **Raspberry Pi 4** | Restaurant-side device | Runs kiosk/print services next to the physical printer |
| **Chromium kiosk / Wayland** | Tablet-style restaurant terminal | Full-screen touch-oriented operator interface |
| **Java print bridge + agent** | Raspberry Pi | Retrieves authorized print jobs, spools them locally and drives the printer |
| **TSPL / USB (`/dev/usb/lp0`)** | Zjiang ZJ-9220 label printer | Renders and outputs kitchen tickets/labels, including bitmap-based CJK text |
| **Noto CJK fonts** | Raspberry Pi print environment | Enables readable Japanese/Korean/Chinese glyph rendering |
| **systemd** | Raspberry Pi | Manages the print bridge and printer agent as background services |

### High-level data flow

```mermaid
flowchart LR
    A[Guest phone / QR menu] --> B[Spring Boot REST API]
    M[Manager / Kitchen / Cashier UI] --> B
    B <--> D[(PostgreSQL)]
    B --> Q[Print-job queue in database]
    Q --> P[Raspberry Pi print bridge]
    P --> S[Local durable spool]
    S --> T[Java print agent]
    T --> U[USB TSPL label printer]
```

### Example workflow

1. A guest scans a table QR code and opens a restaurant-specific menu.
2. The guest sends an order; the Java backend writes the order and its items to PostgreSQL. If enabled, an associated kitchen print job is recorded.
3. The kitchen dashboard displays the order. Staff update preparation/delivery status according to configured workflow.
4. The printer bridge polls for work, keeps a local spool, and the printer agent renders a label and sends it to the USB printer. Acknowledgement does **not** necessarily prove that paper was physically printed.
5. The cashier records a **simulated** payment, closes the table session, and rotates the guest QR/session token.
6. Owner reports aggregate restaurant-scoped operational and sales-demo data.

### Source availability and deployment

This GitHub-ready package contains **documentation only**, not the private production source. The current live codebase must be reviewed, consolidated and sanitized before it can be committed. In particular, do not upload production environment files, access tokens, printer credentials, database exports, customer records, or server backups. See [SECURITY.md](SECURITY.md).

**Project status:** Functional demonstration and ongoing development; not verified for real payment processing, Japanese tax/invoice compliance, production load, or physical print confirmation. Specific components and settings should be checked against the latest deployed build before publishing actual source code.

---

## 日本語

### プロジェクト概要

**Aliator CashRegister** は、飲食店における注文受付からキッチンへの伝達、会計デモ、売上レポート、ラベル印刷までを一連の流れとして実装した **Java / Spring Boot ベースのデモシステム**です。

お客様がテーブルのQRコードをスマートフォンで読み取ると、メニューを閲覧して注文できます。注文内容はキッチン画面に反映され、スタッフは調理状況を管理します。会計担当者は**模擬決済**でテーブルを精算し、管理者は売上・注文状況を確認できます。さらに、Raspberry PiとUSBラベルプリンターを組み合わせ、注文票の印刷にも対応します。

### 主な機能

- **QRコード注文:** テーブルごとのゲストセッション、メニュー表示、注文、会計後のセッション／QRトークン更新
- **店舗管理:** 店舗単位のデータ管理、メニュー・テーブル・印刷設定
- **キッチン画面:** 新規注文の確認、調理完了、必要に応じた配膳確認
- **POSデモ:** 現金・カードの**模擬決済**、明細表示、テーブル会計（実際の決済処理は行いません）
- **管理者レポート:** 日次・週次・月次・年次の売上／注文集計
- **ラベル印刷:** 印刷ジョブの管理、キュー・応答状態、Raspberry PiからのUSB出力
- **多言語UI:** 日本語を基本とし、英語・中国語・韓国語・トルコ語のローカライズを開発
- **タッチ操作:** ブラウザベースの画面とRaspberry Pi上のChromiumキオスク

### 使用技術と担当範囲

| 技術 | 使用箇所 | 役割 |
| --- | --- | --- |
| **Java 21** | サーバー・印刷サービス | 業務ロジックと印刷処理 |
| **Spring Boot 3.x** | アプリケーションサーバー | REST API、注文・認証・会計デモ・レポート・印刷機能 |
| **Spring JDBC / JdbcTemplate** | DBアクセス層 | 店舗単位に分離したSQL処理 |
| **PostgreSQL** | データベース | 店舗、商品、テーブル、セッション、注文、印刷ジョブを保存 |
| **HTML / CSS / JavaScript** | Webフロントエンド | お客様・キッチン・会計・管理・レポート画面 |
| **Docker Compose** | Linuxサーバー | JavaアプリケーションとDBの起動・管理 |
| **Nginx / HTTPS** | Web公開部分 | TLS終端とリバースプロキシ |
| **Raspberry Pi 4** | 店舗側端末 | 印刷ブリッジ・エージェント・キオスクの実行 |
| **Chromium / Wayland** | 店舗端末のUI | タッチ操作向け全画面表示 |
| **Java印刷ブリッジ／エージェント** | Raspberry Pi | ジョブ取得、ローカル保存、印刷機への送信 |
| **TSPL / USB** | Zjiang ZJ-9220 | 厨房用注文票・ラベルを出力 |
| **Noto CJKフォント** | Raspberry Pi | 日本語・韓国語・中国語の文字描画 |
| **systemd** | Raspberry Pi | 印刷サービスの常駐管理 |

### 注文から印刷までの流れ

1. お客様がテーブルのQRコードを読み込み、メニューを表示します。
2. 注文送信後、Spring BootがPostgreSQLに注文データを保存します。設定に応じて印刷ジョブも登録します。
3. キッチン画面に注文が表示され、スタッフが調理・配膳ステータスを更新します。
4. Raspberry Piが印刷ジョブを取得してローカルキューに保存し、JavaエージェントがTSPL形式でUSBプリンターに送信します。**送信完了と実際の紙への印刷完了は同義ではありません。**
5. 会計画面で**模擬決済**を記録するとテーブルが閉じられ、ゲストセッション／QRトークンが更新されます。
6. 管理者は店舗単位でレポートを確認できます。

### ソースコードの公開について

このパッケージに含まれるのは**ドキュメントのみ**であり、本番稼働中のソースコードではありません。ソースコードを公開する際は、最新環境と差分を確認し、秘密情報・認証トークン・顧客データ・DBバックアップを取り除いてください。詳細は[SECURITY.md](SECURITY.md)を参照してください。

**現状:** 機能デモとして開発中です。実決済、適格請求書・税務対応、商用負荷試験、プリンターの物理的な印刷完了検知は検証済み機能として扱いません。
